/***
 * Context to share prayer state between prayer screens
 */
 import { useContext, useMemo, useReducer, Reducer, createContext, Dispatch, SetStateAction, useEffect, useCallback } from "react";
 import { useDispatch, useSelector } from 'react-redux'
 
 import { RecordedItem } from "@/components/audio-recorder/lib";
 
 import { PrayerInput, savePrayers, createPrayerInput } from '@/state/prayers';
 
 type T = PrayerInput<RecordedItem>
 
 /**
  * @param saved: prayer is already saved to backend
  * @param published: prayer should be saved, but also published publicly
  * @param dirty: form (<EditInfoScreen/ >) as touched fields
  * @param complete: prayer is complete. it is safe to navigate away
  */
 type Status = { 
    saved: boolean, published: boolean, dirty: boolean }

 type Context = {
   prayerInput: T|null
   status: Status
   sync: (input: Partial<T>, shouldUpload?: boolean) => void
   setDirty: (dirty: boolean) => void
   publish: () => void
 }
 
 // Internal PrayerInput reducer
 type S = {prayerInput: T, shouldUpload: boolean}
 type R = Reducer<S, {partial: Partial<T>, shouldUpload: boolean}>
 
 // Provider 
 const ScreensContext = createContext<Context>({} as Context)
 
 const ScreensContextProvider = ({prayerId, children}) => {
 
  const dispatch = useDispatch()
  const prayerInputInitial = usePrayerInput(prayerId)

  // Prayer state
  // =============================
  const [{shouldUpload, prayerInput}, set] = useReducer<R>(
    (s, {partial, shouldUpload}) => ({
      shouldUpload, prayerInput: {...(s?.prayerInput ?? {}), ...partial} }), 
      ({prayerInput: prayerInputInitial), shouldUpload: false } as S))

  // Status state
  // =============================
  const [status, setStatus] = useReducer<Reducer<Status, Partial<Status>>>(
    (s,a) => ({...s, ...a}), {saved: false, published: false, dirty: false })
     
  /* Persist prayer -> backend based on state
    UPSERT prayers. iff new prayer, also sync `prayerId` locally.
  ============================= */
  useEffect(() => { 
    (async () => { if(shouldUpload) {
      const [prayer] = await dispatch(savePrayers([prayerInput]))
      setStatus({published: !!prayerInput?.published, dirty: false, saved: true })
      prayer.id && set({partial: {prayerId: prayer.id}, shouldUpload: false}) }
    })()
   }, [prayerInput, shouldUpload])
   
  /* callbacks
  ============================= */
  const sync = useCallback((partial: Partial<T>, shouldUpload=false) => {
    set({partial, shouldUpload}) }, [])
 
  const publish = useCallback(() => set(
    {partial: {published: true}, shouldUpload: true}), [])

  const setDirty = (dirty: boolean) => setStatus({dirty, saved: !dirty})
 
  const value = useMemo(() => ({
    prayerInput, status, 
    sync, publish, setDirty, 
  }), [prayerInput, status, status.saved])
 
  return (
    <ScreensContext.Provider 
      {...{value, children }} 
    />
  )
 
 }
 
 const useScreensContext = () => {
  const context = useContext(ScreensContext)
  if (context === undefined) {
    throw new Error(
      'useScreensContext() must be used within `<ScreensContextProvider/>`') }
  return context
 }


 const usePrayerInput = () => {


export const createPrayerInput = (prayerId: string, state: R): PrayerInput<RecordedItem> => {

  const store = useStore()

  const p = selectPrayerById(prayerId)(state)
  const recordings = 

  return p ? {
    prayerId: p.id, title: p.title, description: p.description, recordings, 
    userId: p.user_id, 
    teamId: p.team_ids?.[0], roomId: p.room_id, topics: p.topics,
    picture_urls?: p.picture_urls, published: p.published, lat_lng?: p.lat_lng,
  } : {
    topics: [],
  }

}
 }
 
 export { ScreensContextProvider, useScreensContext }
 
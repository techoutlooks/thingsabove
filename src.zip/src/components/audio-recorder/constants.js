

export const AUDIO_MAX_DURATION = 60                // 1mn
export const RECORDING_TITLE_PREFIX = 'Prayer '
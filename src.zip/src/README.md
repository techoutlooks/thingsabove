

### supabase

Dependencies:

FIX: error 'supabase URLSearchParams.set is not implemented'
`import 'react-native-url-polyfill/auto';` in index.js
cf. https://twitter.com/JustinNoelDev/status/1336404712132849664
```
yarn add react-native-url-polyfill
```

yarn  @supabase/supabase-js 


Enable push Notifications

- [FCM](https://docs.expo.dev/push-notifications/using-fcm/)
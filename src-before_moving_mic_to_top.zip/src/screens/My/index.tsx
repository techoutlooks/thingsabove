export {default as MyPrayersScreen} from './MyPrayersScreen';



export const IMAGE_WIDTH = 300;
export const IMAGE_HEIGHT = 300;

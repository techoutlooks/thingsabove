const Membership = {
  Joined: 'join',
  Invited: 'invite',
  Knocked: 'knock',
  Left: 'leave',
  Banned: 'ban',
}

export default Membership
